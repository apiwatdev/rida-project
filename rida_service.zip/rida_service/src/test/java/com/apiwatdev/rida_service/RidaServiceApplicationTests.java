package com.apiwatdev.rida_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RidaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
